import{a as t}from"../chunks/entry.FDrsO-P4.js";export{t as start};
